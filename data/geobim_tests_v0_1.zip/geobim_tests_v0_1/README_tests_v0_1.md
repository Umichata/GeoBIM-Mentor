# GeoBIM Mentor — test pack v0_1

Архив содержит тесты для проверки hallucination control, safety guardrails, LLM-as-a-Judge и ручного чата.

Основные наборы:

- `hallucination_traps.csv` — ловушки на ложные команды, перенос терминов между программами, engineering/normative overclaim.
- `safety_test_questions.csv` — неправомерные запросы: лицензии, пиратское ПО, destructive automation, секреты, live API abuse.
- `judge_eval_cases.csv` — контроль OpenAI LLM-as-a-Judge.
- `manual_chat_demo_questions.csv` — вопросы для ручной демонстрации преподавателю.
- `live_gis_demo_questions.csv` — ограниченные запросы к 2GIS demo/live-слою.

Все тесты используют версию v0_1. API-ключи в файлы не включены.

## Update 0.1.1 - test datasets moved from lexicon pack
Updated at: 2026-06-16T10:43:19+00:00

The following regression, parser and demo datasets were moved from `geobim_lexicons_v0_1.zip` into this tests pack:

- `dgis_parser_regression_tests_v0_1.json`
- `final_demo_queries_v0_1.json`
- `hallucination_regression_tests_v0_1.csv`
- `routing_regression_tests_v0_1.csv`
- `safety_regression_tests_v0_1.csv`
- `safety_routing_regression_tests_v0_1.csv`

This keeps lexicons and test datasets in separate archives.


## Update 0.1.6 - expanded independent test pack
Updated at: 2026-06-17T00:37:10+00:00

This update prepares the test pack for the final GitHub-ready GeoBIM Mentor notebook:

- final demo queries are now unique showcase prompts and do not duplicate formal regression suites;
- `safety_routing_regression_tests_v0_1.csv` uses a resource-abuse paraphrase instead of repeating the same 2GIS request count case;
- `hallucination_regression_tests_v0_1.csv` uses a Revit/Civil 3D transfer trap that does not duplicate the baseline hallucination suite;
- `routing_regression_tests_v0_1.csv` treats the Revit Layer Properties Manager prompt as a software-instruction routing case, while hallucination suites validate misconception handling;
- `duplicate_report_v0_1.csv` records exact duplicate queries across suites after normalization.
