# GeoBIM Mentor — internal cases v0_1

Архив содержит авторские учебные markdown-кейсы для базы знаний GeoBIM Mentor. Кейсы не заменяют официальную документацию, а задают типовые рабочие ситуации, терминологию, риски и стиль ответа нейро-сотрудника.

Количество кейсов: 26.

Ключевые расширения версии v0_1:

- CAD/BIM: AutoCAD, Civil 3D, Revit, Dynamo, nanoCAD, КОМПАС-3D, SCAD Office.
- GIS: QGIS, ArcGIS Pro, Google Maps Platform, 2GIS.
- Open standards: IFC/buildingSMART, OGC standards.
- RAG quality: evidence cards, пересказ источников своими словами, grounded generation.

Все файлы UTF-8. API-ключи в архив не включены.
