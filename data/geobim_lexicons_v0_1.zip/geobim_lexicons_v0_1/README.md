# GeoBIM Mentor lexicon pack v0.1.5

Архив содержит словари и служебные правила для GeoBIM Mentor v0.1.

Regression, parser и demo datasets перенесены в `geobim_tests_v0_1.zip`, чтобы словари и тесты хранились отдельно.

Updated at: 2026-06-16T10:43:19+00:00

Перенесённые тестовые файлы:

- `dgis_parser_regression_tests_v0_1.json`
- `final_demo_queries_v0_1.json`
- `hallucination_regression_tests_v0_1.csv`
- `routing_regression_tests_v0_1.csv`
- `safety_regression_tests_v0_1.csv`
- `safety_routing_regression_tests_v0_1.csv`
